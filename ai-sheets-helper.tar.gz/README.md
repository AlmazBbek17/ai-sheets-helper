# AI Sheets Helper - Chrome расширение для Google Sheets

Расширение добавляет две AI-кнопки в Google Sheets:
- 🤖 **Fix Table** - автоматически находит и исправляет ошибки
- ⚡️ **Create Formula** - генерирует формулы по описанию на русском/английском

## Установка

### 1. Развертывание Backend (Vercel)

1. Зарегистрируйтесь на [Vercel](https://vercel.com)
2. Получите API ключ от [OpenRouter](https://openrouter.ai/keys)
3. Склонируйте или загрузите проект
4. Установите Vercel CLI:
```bash
npm install -g vercel
```

5. Войдите в Vercel:
```bash
vercel login
```

6. Разверните проект:
```bash
cd путь/к/проекту
vercel
```

7. Добавьте переменную окружения в настройках проекта Vercel:
   - Откройте проект в Vercel Dashboard
   - Settings → Environment Variables
   - Добавьте: `OPENROUTER_API_KEY` = ваш_ключ

8. Переразверните проект:
```bash
vercel --prod
```

9. Скопируйте URL вашего проекта (например: `https://your-project.vercel.app`)

### 2. Настройка расширения

1. Откройте файл `background.js`
2. Замените `https://your-vercel-app.vercel.app/api` на ваш URL:
```javascript
const VERCEL_API_URL = 'https://your-project.vercel.app/api';
```

### 3. Установка расширения в Chrome

1. Откройте Chrome и перейдите в `chrome://extensions/`
2. Включите "Режим разработчика" (Developer mode) в правом верхнем углу
3. Нажмите "Загрузить распакованное расширение" (Load unpacked)
4. Выберите папку с расширением (где находится manifest.json)
5. Расширение установлено!

### 4. Использование

1. Откройте любую Google Sheets таблицу
2. В панели инструментов появятся две новые кнопки:
   - 🤖 **Fix Table** - выделите диапазон и нажмите для поиска ошибок
   - ⚡️ **Create Formula** - опишите что нужно, AI создаст формулу

## Примеры использования

### Fix Table
1. Выделите диапазон с данными
2. Нажмите "🤖 Fix Table"
3. AI найдет ошибки:
   - Ошибки в формулах (#DIV/0!, #REF!, #N/A)
   - Неправильные типы данных
   - Дубликаты
   - Пустые ячейки
   - Проблемы с датами
4. Просмотрите предложенные исправления
5. Нажмите "Apply" для применения

### Create Formula
1. Нажмите "⚡️ Create Formula"
2. Опишите что нужно:
   - "Посчитай сумму колонки А"
   - "Добавь налог 20% к колонке B"
   - "Покажи только продажи больше 1000"
3. AI сгенерирует формулу
4. Нажмите "Apply Formula" для вставки

## Структура проекта

```
ai-sheets-helper/
├── manifest.json          # Конфигурация расширения (Chrome)
├── background.js          # Service worker (Chrome)
├── content.js            # Скрипт для внедрения кнопок (Chrome)
├── injected.js           # Взаимодействие с Google Sheets API (Chrome)
├── styles.css            # Стили Material Design (Chrome)
├── ICONS.md              # Инструкции по созданию иконок
├── icon16.png            # Иконка 16x16 (создать вручную)
├── icon48.png            # Иконка 48x48 (создать вручную)
├── icon128.png           # Иконка 128x128 (создать вручную)
├── api/                  # Vercel serverless functions
│   ├── fix-table.js      # API для исправления таблиц
│   └── create-formula.js # API для генерации формул
├── vercel.json           # Конфигурация Vercel
├── package.json          # Зависимости для Vercel
├── .env.example          # Пример переменных окружения
├── .gitignore            # Git ignore файл
└── README.md             # Документация (этот файл)
```

### Файлы Chrome расширения (для установки в браузер):
- `manifest.json`, `background.js`, `content.js`, `injected.js`, `styles.css`
- `icon16.png`, `icon48.png`, `icon128.png` (нужно создать, см. ICONS.md)

### Файлы Vercel backend (для деплоя на Vercel):
- `api/`, `vercel.json`, `package.json`, `.env.example`

## Технологии

- **Frontend**: Chrome Extension (Manifest V3)
- **Backend**: Vercel Serverless Functions
- **AI**: OpenRouter API (Claude 3.5 Sonnet)
- **Design**: Google Material Design

## Безопасность

- API ключ хранится только на сервере Vercel
- Пользователь не настраивает ничего
- Все запросы идут через backend
- CORS настроен для безопасности

## Troubleshooting

### Расширение не появляется в Google Sheets
- Проверьте что вы открыли именно Google Sheets (не Google Docs)
- Обновите страницу (F5)
- Проверьте консоль браузера (F12) на ошибки

### Ошибка "API key not configured"
- Убедитесь что добавили `OPENROUTER_API_KEY` в Vercel
- Переразверните проект после добавления переменной

### Кнопки не работают
- Проверьте что указали правильный URL Vercel в `background.js`
- Проверьте что backend развернут и работает
- Откройте Network tab в DevTools и проверьте запросы

## Лицензия

MIT License

## Автор

Создано с помощью Claude AI
