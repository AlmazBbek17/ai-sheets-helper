// Simple script to create placeholder icons using Canvas API
const { createCanvas } = require('canvas');
const fs = require('fs');

function createIcon(size) {
    const canvas = createCanvas(size, size);
    const ctx = canvas.getContext('2d');
    
    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, '#1a73e8');
    gradient.addColorStop(1, '#174ea6');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, size, size);
    
    // Draw AI text
    ctx.fillStyle = 'white';
    ctx.font = `bold ${size * 0.5}px Arial`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('AI', size / 2, size / 2);
    
    // Save
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(`icon${size}.png`, buffer);
    console.log(`Created icon${size}.png`);
}

// Create icons (requires canvas package: npm install canvas)
try {
    [16, 48, 128].forEach(size => createIcon(size));
} catch (e) {
    console.log('Note: To generate icons, install canvas package: npm install canvas');
    console.log('Or create icons manually with any image editor');
}
